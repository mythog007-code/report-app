import 'dart:convert';

String _normalizeDate(String s) {
  s = s.trim();
  if (RegExp(r'^\d{2}/\d{2}/\d{4}$').hasMatch(s)) return s;
  // Older format "30 Sep 2026" -> 30/09/2026
  const m = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  final x = RegExp(r'^(\d{1,2}) ([A-Za-z]{3}) (\d{4})$').firstMatch(s);
  if (x != null) {
    final i = m.indexOf(x[2]!);
    if (i >= 0) {
      return '${x[1]!.padLeft(2, '0')}/${(i + 1).toString().padLeft(2, '0')}/${x[3]}';
    }
  }
  return s;
}

/// A full report: heading, sub heading and the table cells.
class Report {
  int? id;
  String heading;
  String subheading;
  String date; // DD/MM/YYYY, under the heading on the right (optional)
  List<List<String>> cells; // rows x columns
  final int createdAt;
  final bool isTemplate; // true = a template, false = a report

  Report({
    this.id,
    this.heading = '',
    this.subheading = '',
    String? date,
    List<List<String>>? cells,
    int? createdAt,
    this.isTemplate = false,
  })  : cells = cells ?? <List<String>>[],
        date = date ?? '',
        createdAt = createdAt ?? DateTime.now().millisecondsSinceEpoch;

  /// Name shown under the card on Home.
  String get displayName {
    final h = heading.trim().replaceAll('\n', ' ');
    if (h.isNotEmpty) return h;
    const m = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    final d = DateTime.fromMillisecondsSinceEpoch(createdAt);
    return '${isTemplate ? 'Untitled template' : 'Untitled report'} ${d.day} ${m[d.month - 1]} ${d.year}';
  }

  bool get isBlank =>
      heading.trim().isEmpty &&
      subheading.trim().isEmpty &&
      cells.every((r) => r.every((c) => c.trim().isEmpty));

  Map<String, Object?> toMap() => {
        'name': displayName,
        'created_at': createdAt,
        'heading': heading,
        'subheading': subheading,
        'date': date,
        'table_json': jsonEncode(cells),
      };

  factory Report.fromMap(Map<String, Object?> m, {bool isTemplate = false}) {
    List<List<String>>? cells;
    final raw = m['table_json'] as String?;
    if (raw != null && raw.isNotEmpty) {
      cells = (jsonDecode(raw) as List)
          .map((r) => (r as List).map((c) => c as String).toList())
          .toList();
      if (cells.isEmpty || cells[0].isEmpty) cells = null;
    }
    return Report(
      id: m['id'] as int?,
      heading: (m['heading'] as String?) ?? '',
      subheading: (m['subheading'] as String?) ?? '',
      date: _normalizeDate((m['date'] as String?) ?? ''),
      cells: cells,
      createdAt: m['created_at'] as int,
      isTemplate: isTemplate,
    );
  }
}
