/// One card in the grid. Used for both reports and templates.
/// Later parts can add more fields (content, dates, etc.).
class Item {
  final int? id;
  final String name;
  final int createdAt;
  final bool isSample; // true = fake card from sample_data.dart

  const Item({
    this.id,
    required this.name,
    required this.createdAt,
    this.isSample = false,
  });

  factory Item.fromMap(Map<String, Object?> m) => Item(
        id: m['id'] as int?,
        name: m['name'] as String,
        createdAt: m['created_at'] as int,
      );

  Map<String, Object?> toMap() => {
        'name': name,
        'created_at': createdAt,
      };
}
