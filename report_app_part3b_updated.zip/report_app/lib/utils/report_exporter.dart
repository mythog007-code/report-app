import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

import '../models/report.dart';
import '../widgets/report_paper.dart';

/// Renders a report to the same clean PNG paper used by the editor's Save action.
/// The paper is placed off-screen, so the user does not see the editor open.
Future<Uint8List?> renderReportPng(BuildContext context, Report report) async {
  final key = GlobalKey();
  final overlay = Overlay.of(context, rootOverlay: true);
  late OverlayEntry entry;

  entry = OverlayEntry(
    builder: (_) => Positioned(
      left: -10000,
      top: 0,
      width: 380,
      child: Material(
        color: Colors.transparent,
        child: RepaintBoundary(
          key: key,
          child: ReportPaper(
            heading: report.heading,
            subheading: report.subheading,
            date: report.date,
            cells: report.cells,
          ),
        ),
      ),
    ),
  );

  overlay.insert(entry);
  try {
    await WidgetsBinding.instance.endOfFrame;
    await Future.delayed(const Duration(milliseconds: 60));
    final boundary = key.currentContext?.findRenderObject()
        as RenderRepaintBoundary?;
    if (boundary == null) return null;
    final ratio = (4.0).clamp(1.0, 4.0).toDouble();
    final image = await boundary.toImage(pixelRatio: ratio);
    final data = await image.toByteData(format: ui.ImageByteFormat.png);
    return data?.buffer.asUint8List();
  } finally {
    entry.remove();
  }
}
