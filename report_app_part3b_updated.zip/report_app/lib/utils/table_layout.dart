import 'package:flutter/widgets.dart';

/// Shared table sizing (used by the editor AND the saved picture).
/// Wider text -> wider column. Columns always share the screen width.
Map<int, TableColumnWidth> tableColumnWidths(List<List<String>> cells) {
  final map = <int, TableColumnWidth>{};
  if (cells.isEmpty) return map;
  for (var c = 0; c < cells[0].length; c++) {
    var longest = 0;
    for (final row in cells) {
      for (final line in row[c].split('\n')) {
        if (line.length > longest) longest = line.length;
      }
    }
    map[c] = FlexColumnWidth(longest.clamp(6, 40).toDouble());
  }
  return map;
}

double tableFontSize(int cols) =>
    cols <= 4 ? 15.0 : cols <= 6 ? 13.0 : cols <= 8 ? 11.0 : 10.0;

double tableCellPadding(int cols) => cols <= 4 ? 8.0 : cols <= 6 ? 6.0 : 4.0;
