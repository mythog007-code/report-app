import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';

/// Turns typed digits into DD/MM/YYYY. Returns null if the date is impossible.
/// - A first digit that can only start a part (4-9 for day, 2-9 for month)
///   becomes 04..09 and jumps ahead.
/// - "/" is added by itself while typing.
String? formatDateDigits(String digits, {required bool typing}) {
  var i = 0;

  // Reads one 2-digit part (day or month). '' = no digits left, null = invalid.
  String? take(int max) {
    if (i >= digits.length) return '';
    final a = int.parse(digits[i]);
    if (a > max ~/ 10) {
      i++;
      return '0$a';
    }
    i++;
    if (i >= digits.length) return '$a'; // waiting for the 2nd digit
    final v = a * 10 + int.parse(digits[i]);
    if (v < 1 || v > max) return null;
    i++;
    return v.toString().padLeft(2, '0');
  }

  final day = take(31);
  if (day == null) return null;
  final month = day.length == 2 ? take(12) : '';
  if (month == null) return null;
  var year = '';
  if (month.length == 2) {
    year = digits.substring(i);
    if (year.length > 4) year = year.substring(0, 4);
  }

  if (day.length == 2 && month.length == 2) {
    final d = int.parse(day), m = int.parse(month);
    const days = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    if (d > days[m - 1]) return null; // e.g. 31/02, 31/04
    if (year.length == 4) {
      final y = int.parse(year);
      if (y < 1) return null;
      final leap = (y % 4 == 0 && y % 100 != 0) || y % 400 == 0;
      if (d == 29 && m == 2 && !leap) return null;
    }
  }

  final sb = StringBuffer(day);
  if (day.length == 2 && (month.isNotEmpty || typing)) sb.write('/');
  sb.write(month);
  if (month.length == 2 && (year.isNotEmpty || typing)) sb.write('/');
  sb.write(year);
  return sb.toString();
}

class DateInputFormatter extends TextInputFormatter {
  final VoidCallback onInvalid;
  DateInputFormatter({required this.onInvalid});

  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    final deleting = newValue.text.length < oldValue.text.length;
    final digits = newValue.text.replaceAll(RegExp(r'[^0-9]'), '');
    final text = formatDateDigits(digits, typing: !deleting);
    if (text == null) {
      onInvalid();
      return oldValue; // do not accept an impossible date
    }
    return TextEditingValue(
      text: text,
      selection: TextSelection.collapsed(offset: text.length),
    );
  }
}
