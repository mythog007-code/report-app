import 'package:flutter/material.dart';

// The only two colors in the whole app.
const Color kBlack = Color(0xFF000000);
const Color kWhite = Color(0xFFFFFFFF);

ThemeData buildAppTheme() {
  return ThemeData(
    useMaterial3: false,
    scaffoldBackgroundColor: kWhite,
    canvasColor: kWhite,
    colorScheme: const ColorScheme.light(
      primary: kBlack,
      onPrimary: kWhite,
      surface: kWhite,
      onSurface: kBlack,
    ),
    snackBarTheme: const SnackBarThemeData(
      backgroundColor: kBlack,
      contentTextStyle: TextStyle(color: kWhite, fontSize: 15),
      actionTextColor: kWhite,
    ),
    splashFactory: NoSplash.splashFactory,
    highlightColor: Colors.transparent,
    appBarTheme: const AppBarTheme(
      backgroundColor: kWhite,
      foregroundColor: kBlack,
      elevation: 0,
      iconTheme: IconThemeData(color: kBlack),
    ),
    textTheme: const TextTheme(
      bodyMedium: TextStyle(color: kBlack, fontSize: 15),
    ),
  );
}
