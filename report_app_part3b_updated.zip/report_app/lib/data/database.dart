import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

/// Local phone database (works offline, survives closing the app).
class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();

  Database? _db;

  Future<Database> get db async => _db ??= await _open();

  Future<Database> _open() async {
    final path = join(await getDatabasesPath(), 'report_app.db');
    return openDatabase(
      path,
      version: 4,
      onCreate: (d, version) async {
        await d.execute('''
          CREATE TABLE reports(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            heading TEXT,
            subheading TEXT,
            table_json TEXT,
            date TEXT
          )''');
        await d.execute('''
          CREATE TABLE templates(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            heading TEXT,
            subheading TEXT,
            table_json TEXT,
            date TEXT
          )''');
      },
      // Version 1 -> 2 (Part 2): reports get heading, sub heading, table.
      onUpgrade: (d, oldV, newV) async {
        if (oldV < 2) {
          await d.execute('ALTER TABLE reports ADD COLUMN heading TEXT');
          await d.execute('ALTER TABLE reports ADD COLUMN subheading TEXT');
          await d.execute('ALTER TABLE reports ADD COLUMN table_json TEXT');
        }
        // Version 2 -> 3 (Part 3 fix): templates get their own real content.
        if (oldV < 3) {
          await d.execute('ALTER TABLE templates ADD COLUMN heading TEXT');
          await d.execute('ALTER TABLE templates ADD COLUMN subheading TEXT');
          await d.execute('ALTER TABLE templates ADD COLUMN table_json TEXT');
        }
        // Version 3 -> 4: a date under the heading.
        if (oldV < 4) {
          await d.execute('ALTER TABLE reports ADD COLUMN date TEXT');
          await d.execute('ALTER TABLE templates ADD COLUMN date TEXT');
        }
      },
    );
  }
}
