import '../models/item.dart';
import '../models/report.dart';
import 'database.dart';

/// The only place screens use to read/save data.
/// Reports and templates use the same shape, but live in separate tables.
class Repository {
  String _table(bool isTemplate) => isTemplate ? 'templates' : 'reports';

  Future<List<Item>> getReports() => _list('reports');
  Future<List<Item>> getTemplates() => _list('templates');

  Future<List<Item>> _list(String table) async {
    final db = await AppDatabase.instance.db;
    final rows = await db.query(table,
        columns: ['id', 'name', 'created_at'], orderBy: 'created_at DESC');
    return rows.map(Item.fromMap).toList();
  }

  Future<Report?> getReport(int id, {bool isTemplate = false}) async {
    final db = await AppDatabase.instance.db;
    final rows = await db
        .query(_table(isTemplate), where: 'id = ?', whereArgs: [id]);
    return rows.isEmpty
        ? null
        : Report.fromMap(rows.first, isTemplate: isTemplate);
  }

  /// Inserts a new report/template or updates an existing one. Returns its id.
  Future<int> saveReport(Report r) async {
    final db = await AppDatabase.instance.db;
    final t = _table(r.isTemplate);
    if (r.id == null) return db.insert(t, r.toMap());
    await db.update(t, r.toMap(), where: 'id = ?', whereArgs: [r.id]);
    return r.id!;
  }

  Future<void> deleteReport(int id, {bool isTemplate = false}) async {
    final db = await AppDatabase.instance.db;
    await db.delete(_table(isTemplate), where: 'id = ?', whereArgs: [id]);
  }
}
