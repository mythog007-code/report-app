import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models/item.dart';

/// Grid of square cards with a 3-dot menu in the top-right of every card.
/// Used by both the Home and Template tabs.
class ItemGrid extends StatelessWidget {
  final List<Item> items;
  final String emptyMessage;
  final void Function(Item item)? onTap;
  final void Function(Item item, String action)? onMenu;

  const ItemGrid({
    super.key,
    required this.items,
    required this.emptyMessage,
    this.onTap,
    this.onMenu,
  });

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Text(emptyMessage,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 16, color: kBlack)),
        ),
      );
    }
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 110),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 20,
        mainAxisSpacing: 16,
        childAspectRatio: 0.82,
      ),
      itemCount: items.length,
      itemBuilder: (context, i) {
        final item = items[i];
        return GestureDetector(
          onTap: onTap == null ? null : () => onTap!(item),
          behavior: HitTestBehavior.opaque,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              AspectRatio(
                aspectRatio: 1,
                child: Container(
                  decoration: BoxDecoration(
                    color: kWhite,
                    border: Border.all(color: kBlack, width: 2),
                  ),
                  child: Stack(
                    children: [
                      Positioned(
                        top: 0,
                        right: 0,
                        child: PopupMenuButton<String>(
                          padding: EdgeInsets.zero,
                          constraints: const BoxConstraints(
                              minWidth: 40, minHeight: 40),
                          iconSize: 20,
                          icon: const Icon(Icons.more_vert, color: kBlack),
                          color: kWhite,
                          elevation: 0,
                          shape: const RoundedRectangleBorder(
                            side: BorderSide(color: kBlack, width: 2),
                          ),
                          onSelected: (action) => onMenu?.call(item, action),
                          itemBuilder: (_) => const [
                            PopupMenuItem<String>(value: 'edit', child: Text('Edit', style: TextStyle(fontWeight: FontWeight.w700, color: kBlack))),
                            PopupMenuDivider(height: 1),
                            PopupMenuItem<String>(value: 'save', child: Text('Save', style: TextStyle(fontWeight: FontWeight.w700, color: kBlack))),
                            PopupMenuDivider(height: 1),
                            PopupMenuItem<String>(value: 'template', child: Text('Template', style: TextStyle(fontWeight: FontWeight.w700, color: kBlack))),
                            PopupMenuDivider(height: 1),
                            PopupMenuItem<String>(value: 'delete', child: Text('Delete', style: TextStyle(fontWeight: FontWeight.w700, color: kBlack))),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Text(item.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 15, color: kBlack)),
            ],
          ),
        );
      },
    );
  }
}
