import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../utils/table_layout.dart';

/// The clean "paper page" used to make the PNG picture.
/// No buttons, no menu, no hints. Empty heading/sub heading take no space.
class ReportPaper extends StatelessWidget {
  final String heading;
  final String subheading;
  final String date;
  final List<List<String>> cells;

  const ReportPaper({
    super.key,
    required this.heading,
    required this.subheading,
    required this.date,
    required this.cells,
  });

  @override
  Widget build(BuildContext context) {
    final cols = cells.isEmpty ? 0 : cells[0].length;
    final fs = tableFontSize(cols);
    final pad = tableCellPadding(cols);
    return Container(
      color: kWhite,
      padding: const EdgeInsets.all(12),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (heading.trim().isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: SizedBox(
                width: double.infinity,
                child: Text(heading,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontSize: 26, fontWeight: FontWeight.w800, color: kBlack)),
              ),
            ),
          if (date.trim().isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: SizedBox(
                width: double.infinity,
                child: Text(date,
                    textAlign: TextAlign.right,
                    style: const TextStyle(fontSize: 14, color: kBlack)),
              ),
            ),
          if (subheading.trim().isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text(subheading,
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.w700, color: kBlack)),
            ),
          if (cells.isNotEmpty)
            Table(
            border: TableBorder.all(color: kBlack, width: 1.5),
            columnWidths: tableColumnWidths(cells),
            children: [
              for (final row in cells)
                TableRow(children: [
                  for (final t in row)
                    Padding(
                      padding: EdgeInsets.all(pad),
                      child: Text(t, style: TextStyle(fontSize: fs, color: kBlack)),
                    ),
                ]),
            ],
          ),
        ],
      ),
    );
  }
}
