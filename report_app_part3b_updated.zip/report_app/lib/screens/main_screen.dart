import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:gal/gal.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'dart:io';

import '../app_theme.dart';
import '../data/repository.dart';
import '../models/item.dart';
import '../models/report.dart';
import '../utils/report_exporter.dart';
import '../widgets/item_grid.dart';
import 'editor_screen.dart';

/// Home + Template screens and their card menus.
class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen>
    with SingleTickerProviderStateMixin {
  final _repo = Repository();
  late final TabController _tabs = TabController(length: 2, vsync: this);

  List<Item> _reports = [];
  List<Item> _templates = [];

  @override
  void initState() {
    super.initState();
    _tabs.addListener(() => setState(() {}));
    _load();
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final r = await _repo.getReports();
    final t = await _repo.getTemplates();
    if (!mounted) return;
    setState(() {
      _reports = r;
      _templates = t;
    });
  }

  Future<void> _openEditor({int? id, bool template = false, bool edit = false}) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => EditorScreen(
          reportId: id,
          isTemplate: template,
          startEditing: edit,
        ),
      ),
    );
    _load();
  }

  Future<Report?> _loadItem(Item item, {required bool template}) async {
    if (item.id == null) return null;
    return _repo.getReport(item.id!, isTemplate: template);
  }

  Future<void> _cardMenu(Item item, String action, {required bool template}) async {
    final r = await _loadItem(item, template: template);
    if (r == null || !mounted) return;

    switch (action) {
      case 'edit':
        await _openEditor(id: r.id, template: template, edit: true);
        break;
      case 'save':
        await _savePicture(r);
        break;
      case 'template':
        if (!template) {
          _msg('Coming in the next update');
          return;
        }
        final copy = Report(
          heading: r.heading,
          subheading: r.subheading,
          date: r.date,
          cells: r.cells.map((row) => List<String>.from(row)).toList(),
          isTemplate: false,
        );
        final id = await _repo.saveReport(copy);
        await _openEditor(id: id, template: false, edit: true);
        break;
      case 'delete':
        await _deleteItem(r, template: template);
        break;
    }
  }

  Future<void> _savePicture(Report report) async {
    final png = await renderReportPng(context, report);
    if (png == null) {
      _msg('Could not make the picture');
      return;
    }
    try {
      if (!await Gal.hasAccess(toAlbum: true)) {
        if (!await Gal.requestAccess(toAlbum: true)) {
          _msg('Please allow photo/storage access to save the picture');
          return;
        }
      }
      await Gal.putImageBytes(png, album: 'Reports');
    } on GalException {
      _msg('Could not save the picture to the gallery');
      return;
    }

    _msg('Saved', action: SnackBarAction(label: 'Share', onPressed: () => _share(png)));
  }

  Future<void> _share(Uint8List png) async {
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/report_${DateTime.now().millisecondsSinceEpoch}.png');
    await file.writeAsBytes(png);
    await Share.shareXFiles([XFile(file.path)]);
  }

  Future<void> _deleteItem(Report r, {required bool template}) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        backgroundColor: kWhite,
        elevation: 0,
        shape: const RoundedRectangleBorder(
          side: BorderSide(color: kBlack, width: 2),
        ),
        content: const Text(
          'Are you sure you want to delete this?',
          style: TextStyle(fontSize: 16, color: kBlack),
        ),
        actions: [
          TextButton(
            style: TextButton.styleFrom(foregroundColor: kBlack),
            onPressed: () => Navigator.pop(c, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            style: TextButton.styleFrom(
              foregroundColor: kBlack,
              textStyle: const TextStyle(fontWeight: FontWeight.w800),
            ),
            onPressed: () => Navigator.pop(c, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok != true || r.id == null) return;
    await _repo.deleteReport(r.id!, isTemplate: template);
    await _load();
  }

  void _msg(String text, {SnackBarAction? action}) {
    if (!mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    messenger.hideCurrentSnackBar();
    messenger.showSnackBar(SnackBar(
      content: Text(text),
      action: action,
      duration: Duration(seconds: action == null ? 3 : 8),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 0,
        bottom: TabBar(
          controller: _tabs,
          isScrollable: true,
          tabAlignment: TabAlignment.center,
          labelPadding: const EdgeInsets.symmetric(horizontal: 24),
          labelColor: kBlack,
          unselectedLabelColor: kBlack,
          indicatorColor: kBlack,
          indicatorWeight: 3,
          indicatorSize: TabBarIndicatorSize.label,
          dividerColor: Colors.transparent,
          labelStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
          unselectedLabelStyle:
              const TextStyle(fontSize: 18, fontWeight: FontWeight.w400),
          tabs: const [Tab(text: 'Home'), Tab(text: 'Template')],
        ),
      ),
      body: TabBarView(
        controller: _tabs,
        children: [
          ItemGrid(
            items: _reports,
            onTap: (item) => _openEditor(id: item.id),
            onMenu: (item, action) => _cardMenu(item, action, template: false),
            emptyMessage: 'No reports yet. Tap + to create one.',
          ),
          ItemGrid(
            items: _templates,
            onTap: (item) => _openEditor(id: item.id, template: true),
            onMenu: (item, action) => _cardMenu(item, action, template: true),
            emptyMessage: 'No templates yet.',
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _openEditor(template: _tabs.index == 1),
        backgroundColor: kWhite,
        foregroundColor: kBlack,
        elevation: 0,
        highlightElevation: 0,
        shape: const CircleBorder(side: BorderSide(color: kBlack, width: 2)),
        child: const Icon(Icons.add, size: 34),
      ),
    );
  }
}
