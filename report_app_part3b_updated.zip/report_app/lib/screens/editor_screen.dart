import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:gal/gal.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../app_theme.dart';
import '../data/repository.dart';
import '../models/report.dart';
import '../utils/date_input.dart';
import '../utils/report_exporter.dart';
import '../utils/table_layout.dart';
import '../widgets/report_paper.dart';

/// The report editor.
/// New report (reportId == null) -> edit mode. Old report -> view mode.
class EditorScreen extends StatefulWidget {
  final int? reportId;
  final bool isTemplate; // true = editing a template
  final bool startEditing;
  const EditorScreen({super.key, this.reportId, this.isTemplate = false, this.startEditing = false});

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen>
    with WidgetsBindingObserver {
  final _repo = Repository();
  final _heading = TextEditingController();
  final _sub = TextEditingController();
  final _date = TextEditingController();
  final _scroll = ScrollController();
  final _paperKey = GlobalKey();
  List<List<TextEditingController>> _cells = [];

  Report? _report;
  late bool _editing = widget.reportId == null || widget.startEditing;
  bool _loaded = false;
  bool _touched = false;
  bool _deleted = false;
  bool _exporting = false; // true only while making the picture
  Uint8List? _lastPng;
  int? _templateId; // id of the template copy made from this report
  late final _dateFormatter =
      DateInputFormatter(onInvalid: () => _msg('Invalid date'));
  Timer? _timer;
  Future<void> _queue = Future.value();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _heading.addListener(_changed);
    _sub.addListener(_changed);
    _date.addListener(_changed);
    _init();
  }

  Future<void> _init() async {
    Report? r;
    if (widget.reportId != null) r = await _repo.getReport(widget.reportId!, isTemplate: widget.isTemplate);
    r ??= Report(isTemplate: widget.isTemplate);
    _report = r;
    _heading.text = r.heading;
    _sub.text = r.subheading;
    _date.text = r.date;
    _cells = r.cells.map((row) => row.map(_makeCtrl).toList()).toList();
    if (mounted) setState(() => _loaded = true);
  }

  TextEditingController _makeCtrl(String text) =>
      TextEditingController(text: text)..addListener(_changed);

  List<List<String>> _texts() =>
      _cells.map((row) => row.map((c) => c.text).toList()).toList();

  void _changed() {
    if (!_loaded || !_editing) return;
    setState(() {});
    _timer?.cancel();
    _timer = Timer(const Duration(milliseconds: 600), _save);
  }

  Future<void> _save({bool force = false}) {
    _timer?.cancel();
    _queue = _queue.then((_) async {
      final r = _report;
      if (r == null || !_loaded || _deleted) return;
      if (!_editing && !force) return; // view mode: nothing to save
      r.heading = _heading.text;
      r.subheading = _sub.text;
      r.date = _date.text;
      r.cells = _texts();
      if (!force && r.id == null && r.isBlank && !_touched) return;
      r.id = await _repo.saveReport(r);
    });
    return _queue;
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) _save();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _timer?.cancel();
    _heading.dispose();
    _sub.dispose();
    _date.dispose();
    for (final row in _cells) {
      for (final c in row) {
        c.dispose();
      }
    }
    _scroll.dispose();
    super.dispose();
  }

  // Row / column + and - (an empty table starts with nothing).
  void _disposeLater(List<TextEditingController> list) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      for (final c in list) {
        c.dispose();
      }
    });
  }

  void _addRow() {
    setState(() {
      _touched = true;
      final n = _cells.isEmpty ? 1 : _cells[0].length;
      _cells.add(List.generate(n, (_) => _makeCtrl('')));
    });
    _changed();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
      }
    });
  }

  void _addColumn() {
    setState(() {
      _touched = true;
      if (_cells.isEmpty) {
        _cells.add([_makeCtrl('')]);
      } else {
        for (final row in _cells) {
          row.add(_makeCtrl(''));
        }
      }
    });
    _changed();
  }

  void _removeRow() {
    if (_cells.isEmpty) return;
    setState(() {
      _touched = true;
      _disposeLater(_cells.removeLast());
    });
    _changed();
  }

  void _removeColumn() {
    if (_cells.isEmpty) return;
    setState(() {
      _touched = true;
      final gone = <TextEditingController>[];
      for (final row in _cells) {
        gone.add(row.removeLast());
      }
      if (_cells[0].isEmpty) _cells.clear(); // last column removed = no table
      _disposeLater(gone);
    });
    _changed();
  }

  /// Menu > Template: saves a copy of this report as a template.
  Future<void> _saveAsTemplate() async {
    if (widget.isTemplate) {
      _msg('This is already a template');
      return;
    }
    final t = Report(
      id: _templateId, // pressing again updates the same template
      heading: _heading.text,
      subheading: _sub.text,
      date: _date.text,
      cells: _texts(),
      isTemplate: true,
    );
    t.id = await _repo.saveReport(t);
    _templateId = t.id;
    _msg('Saved as template');
  }

  // ---------------- 3-dot menu actions ----------------
  void _onMenu(String action) {
    switch (action) {
      case 'edit':
        if (!_editing) setState(() => _editing = true);
        break;
      case 'save':
        _exportSave();
        break;
      case 'template':
        _saveAsTemplate();
        break;
      case 'delete':
        _delete();
        break;
    }
  }

  void _msg(String text, {SnackBarAction? action}) {
    if (!mounted) return;
    final m = ScaffoldMessenger.of(context);
    m.hideCurrentSnackBar();
    m.showSnackBar(SnackBar(
        content: Text(text),
        action: action,
        duration: Duration(seconds: action == null ? 3 : 8)));
  }

  /// Makes one sharp PNG of the paper page (full length, white background).
  Future<Uint8List?> _renderPng() async {
    setState(() => _exporting = true);
    try {
      return await renderReportPng(context, _report!);
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }

  Future<void> _exportSave() async {
    await _save(force: true); // 1) save inside the app
    final png = await _renderPng(); // 2) make the picture
    if (png == null) {
      _msg('Could not make the picture');
      return;
    }
    try {
      if (!await Gal.hasAccess(toAlbum: true)) {
        if (!await Gal.requestAccess(toAlbum: true)) {
          _msg('Please allow photo/storage access to save the picture');
          return;
        }
      }
      await Gal.putImageBytes(png, album: 'Reports'); // 3) gallery
    } on GalException {
      _msg('Could not save the picture to the gallery');
      return;
    }
    _lastPng = png;
    if (!mounted) return;
    setState(() => _editing = false); // back to view mode
    _msg('Saved', action: SnackBarAction(label: 'Share', onPressed: _share));
  }

  Future<void> _share() async {
    final png = _lastPng;
    if (png == null) return;
    final dir = await getTemporaryDirectory();
    final file = File(
        '${dir.path}/report_${DateTime.now().millisecondsSinceEpoch}.png');
    await file.writeAsBytes(png);
    await Share.shareXFiles([XFile(file.path)]);
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        backgroundColor: kWhite,
        elevation: 0,
        shape: const RoundedRectangleBorder(
            side: BorderSide(color: kBlack, width: 2)),
        content: Text(
            'Are you sure you want to delete this ${widget.isTemplate ? 'template' : 'report'}?',
            style: const TextStyle(fontSize: 16, color: kBlack)),
        actions: [
          TextButton(
            style: TextButton.styleFrom(foregroundColor: kBlack),
            onPressed: () => Navigator.pop(c, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            style: TextButton.styleFrom(
                foregroundColor: kBlack,
                textStyle: const TextStyle(fontWeight: FontWeight.w800)),
            onPressed: () => Navigator.pop(c, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    _deleted = true; // stop any more saving
    _timer?.cancel();
    await _queue;
    final id = _report?.id;
    if (id != null) await _repo.deleteReport(id, isTemplate: widget.isTemplate);
    if (mounted) Navigator.pop(context);
  }

  // ---------------- UI ----------------
  Widget _titleField(TextEditingController c, String hint, TextStyle style,
      TextAlign align,
      {TextInputType? keyboardType, List<TextInputFormatter>? formatters}) {
    return TextField(
      controller: c,
      maxLines: null,
      readOnly: !_editing,
      showCursor: _editing,
      enableInteractiveSelection: _editing,
      textAlign: align,
      keyboardType: keyboardType,
      inputFormatters: formatters,
      style: style,
      cursorColor: kBlack,
      decoration: InputDecoration(
        isDense: true,
        border: InputBorder.none,
        hintText: _editing ? hint : null,
        hintStyle: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w400,
            fontStyle: FontStyle.italic,
            color: Color(0x4D000000)),
        contentPadding: const EdgeInsets.symmetric(vertical: 6),
      ),
    );
  }

  PopupMenuItem<String> _item(String value, String label) => PopupMenuItem(
        value: value,
        child: Text(label,
            style: const TextStyle(fontWeight: FontWeight.w700, color: kBlack)),
      );

  Widget _menu() => PopupMenuButton<String>(
        icon: const Icon(Icons.more_vert),
        color: kWhite,
        elevation: 0,
        shape: const RoundedRectangleBorder(
            side: BorderSide(color: kBlack, width: 2)),
        onSelected: _onMenu,
        itemBuilder: (_) => [
          _item('edit', 'Edit'),
          const PopupMenuDivider(height: 1),
          _item('save', 'Save'),
          const PopupMenuDivider(height: 1),
          _item('template', 'Template'),
          const PopupMenuDivider(height: 1),
          _item('delete', 'Delete'),
        ],
      );

  Widget _stepper(String label, VoidCallback onMinus, VoidCallback onPlus) {
    Widget half(IconData icon, VoidCallback f) => InkWell(
          onTap: f,
          child: SizedBox(width: 46, height: 44, child: Icon(icon, color: kBlack)),
        );
    return Container(
      width: 150,
      height: 44,
      decoration: BoxDecoration(
          color: kWhite, border: Border.all(color: kBlack, width: 2)),
      child: Row(
        children: [
          half(Icons.remove, onMinus),
          Expanded(
            child: Center(
              child: Text(label,
                  style: const TextStyle(
                      fontWeight: FontWeight.w700, fontSize: 14, color: kBlack)),
            ),
          ),
          half(Icons.add, onPlus),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) return const Scaffold(body: SizedBox.expand());

    final cols = _cells.isEmpty ? 0 : _cells[0].length;
    final fontSize = tableFontSize(cols);
    final pad = tableCellPadding(cols);
    final showHeading = _editing || _heading.text.trim().isNotEmpty;
    final showSub = _editing || _sub.text.trim().isNotEmpty;
    final showDate = _editing || _date.text.trim().isNotEmpty;

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        if (_editing) await _save(); // never lose what was typed
        if (mounted) Navigator.pop(context);
      },
      child: Scaffold(
        body: SafeArea(
          child: Stack(
            children: [
              SingleChildScrollView(
                controller: _scroll,
                padding: const EdgeInsets.fromLTRB(8, 4, 8, 170),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.arrow_back),
                          onPressed: () => Navigator.maybePop(context),
                        ),
                        Expanded(
                          child: showHeading
                              ? _titleField(
                                  _heading,
                                  'Heading',
                                  const TextStyle(
                                      fontSize: 26,
                                      fontWeight: FontWeight.w800,
                                      color: kBlack),
                                  TextAlign.center)
                              : const SizedBox.shrink(),
                        ),
                        _menu(),
                      ],
                    ),
                    if (showDate)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8),
                        child: Align(
                          alignment: Alignment.centerRight,
                          child: SizedBox(
                            width: 130,
                            child: _titleField(
                              _date,
                              '00/00/0000',
                              const TextStyle(fontSize: 14, color: kBlack),
                              TextAlign.right,
                              keyboardType: TextInputType.number,
                              formatters: [_dateFormatter],
                            ),
                          ),
                        ),
                      ),
                    if (showSub)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8),
                        child: _titleField(
                            _sub,
                            'Sub heading',
                            const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w700,
                                color: kBlack),
                            TextAlign.left),
                      ),
                    const SizedBox(height: 6),
                    if (_cells.isNotEmpty)
                    Table(
                      border: TableBorder.all(color: kBlack, width: 1.5),
                      columnWidths: tableColumnWidths(_texts()),
                      children: [
                        for (final row in _cells)
                          TableRow(children: [
                            for (final c in row)
                              TextField(
                                controller: c,
                                maxLines: null,
                                readOnly: !_editing,
                                showCursor: _editing,
                                enableInteractiveSelection: _editing,
                                keyboardType: TextInputType.multiline,
                                cursorColor: kBlack,
                                style: TextStyle(
                                    fontSize: fontSize, color: kBlack),
                                decoration: InputDecoration(
                                  isDense: true,
                                  border: InputBorder.none,
                                  contentPadding: EdgeInsets.all(pad),
                                ),
                              ),
                          ]),
                      ],
                    ),
                  ],
                ),
              ),
              // Hidden paper used ONLY while making the picture.
              if (_exporting)
                Positioned(
                  left: -3000,
                  top: 0,
                  width: 380,
                  child: OverflowBox(
                    alignment: Alignment.topLeft,
                    minHeight: 0,
                    maxHeight: double.infinity,
                    child: RepaintBoundary(
                      key: _paperKey,
                      child: ReportPaper(
                        heading: _heading.text,
                        subheading: _sub.text,
      date: _date.text,
                        cells: _texts(),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
        floatingActionButton: _editing
            ? IntrinsicWidth(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _stepper('Row', _removeRow, _addRow),
                    const SizedBox(height: 10),
                    _stepper('Column', _removeColumn, _addColumn),
                  ],
                ),
              )
            : null,
      ),
    );
  }
}
