# Report App - Part 3B (Flutter)

This is the Android/Flutter version of the report app, updated from the supplied Flutter project with Part 3B.

## Part 3B included
- 3-dot button on every Home and Template card.
- Card menu: Edit, Save, Template, Delete.
- Edit opens directly in edit mode.
- Save creates the same clean black/white PNG used by the editor and saves it to the Android gallery, then offers Share.
- Home card > Template shows `Coming in the next update`.
- Template card > Template creates a new report copy and opens it in edit mode.
- Delete asks `Are you sure you want to delete this?` and removes the card after confirmation.
- Reports/templates remain offline in the phone database.

## Build on Windows
This ZIP is the Flutter source project. It is not an APK by itself.

1. Install Flutter and Android Studio/Android SDK.
2. Open a Command Prompt in the project folder.
3. Run:
   flutter pub get
4. Connect your Android phone with USB debugging enabled.
5. Test it:
   flutter run
6. Build the installable APK:
   flutter build apk --release

The APK will be at:
`build\app\outputs\flutter-apk\app-release.apk`

Copy that APK to the phone and install it. Android may ask you to allow installation from that source.

## If this ZIP does not contain the generated Android platform folder
Because the source package may be distributed without generated platform files, run this once in a new Flutter project:

`flutter create --org com.myreports --project-name report_app report_app`

Then copy the `lib` folder and `pubspec.yaml` from this package into that generated project and run `flutter pub get`.
